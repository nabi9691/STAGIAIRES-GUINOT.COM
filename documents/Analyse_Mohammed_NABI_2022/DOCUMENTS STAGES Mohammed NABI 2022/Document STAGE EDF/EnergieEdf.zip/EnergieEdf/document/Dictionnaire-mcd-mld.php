ENTREPRISE EDF
Fournisseur de Gaz & d'Électricité  
énergies renouvelables 
service des eaux 

Dictionnaire de données
- agence
    villes et départements
    référence
 options
    date et heure de début
    date et heure de fin
    statut
type de service    

___________________________________________________


Règles de gestion


    - Une agence peut avoir un ou plusieur clients
    - Un client ne peut s'abonner qu'à une seul agence 
    - Un client peut signer un et un seul contra par agence
- un contra peut contenir un ou plusieurs services
- un services peut  ètre inclu dans un ou plusieurs contras
    - Une agence peut avoir un ou plusieur prestateurs
    - Une agence ne peut pas avoir plus de trois gestionnaires
    - Le gestionnaires gère uniquement son agence

___________________________________________________

<MCD>

Mes entités;


1. agence

    age_id int (PK)
    age_ville  varchar(100)
    age_departement varchar(100)
age_telephone varchar (100) 
age_adresse varchar (100) 
age_info varchar (150) 


2. service

    ser_id int (PK)
    ser_libelle varchar(100)
    ser_prix float


3. client

 cli_id int (PK)
 cli_nom varchar(100)
 cli_prenom varchar(100)
    cli_login varchar(100)
    cli_mdp varchar(100)
    cli_adresse varchar(100)
    cli_email varchar(100)
   cli_telephone varchar(20)


4. prestateur

 pre_id int (PK)
 pre_nom varchar(100)
 pre_prenom varchar(100)
    pre_login varchar(100)
    pre_mdp varchar(100)
    pre_adresse varchar(100)
    pre_email varchar(100)
   pre_telephone varchar(20)
pre_debut datetime
pre_fin datetime


5. employe

 emp_id int (PK)
 emp_nom varchar(100)
 emp_prenom varchar(100)
    emp_login varchar(100)
    emp_mdp varchar(100)
emp_profil varchar(100)


6. contra

 con_id int (PK)
con_debut datetime
con_fin datetime
con_type varchar(100)
con_statut varchar(100)



___________________________________________________


<associations>


1. abonner
    agence: 1,n
    client: 1,1
cli_agence;


2. signer
client: 1,n
contra: 1,1
con_client;


3. avoir
agence: 1,n
contra: 1,1
con_agence;


4. engager
agence: 1,n
prestateur: 1,1
pre_agence;


5. gérer (profil==  "gestionnaire");
agence: 1,n
gestionnaire: 1,1
emp_agence;


6. comprendre
contra: 1,n
service: 1,n

La création d'une table (N,N);
com_contra;
com_service;



</MCD>


___________________________________________________


<MLD>


1. agence

    age_id int (PK)
    age_ville  varchar(100)
    age_departement varchar(100)
age_telephone varchar (100) 
age_adresse varchar (100) 
age_info varchar (150) 


2. service

    ser_id int (PK)
    ser_libelle varchar(100)
    ser_prix float


3. client

 cli_id int (PK)
 cli_nom varchar(100)
 cli_prenom varchar(100)
    cli_login varchar(100)
    cli_mdp varchar(100)
    cli_adresse varchar(100)
    cli_email varchar(100)
   cli_telephone varchar(20)
cli_agence int


4. prestateur

 pre_id int (PK)
 pre_nom varchar(100)
 pre_prenom varchar(100)
    pre_login varchar(100)
    pre_mdp varchar(100)
    pre_adresse varchar(100)
    pre_email varchar(100)
   pre_telephone varchar(20)
pre_debut datetime
pre_fin datetime
pre_agence int


5. employe

 emp_id int (PK)
 emp_nom varchar(100)
 emp_prenom varchar(100)
    emp_login varchar(100)
    emp_mdp varchar(100)
emp_profil varchar(100)
emp_agence int 


6. contra

 con_id int (PK)
con_debut datetime
con_fin datetime
con_type varchar(100)
con_statut varchar(100)
con_agence int not null
con_client int not null


7. comprendre

 com_id int (PK)
 com_contra int
 com_service int



___________________________________________________




</MLD>

Stage EDF/NABI 2020/2021: GUINOT.

