<?php


$libelles = array(
'Électricité', 'Gaz', 'eau', 'tarifs', 'Facturation', 'Résiliation', 'changement de propriétaire', 'relevé de compteur', 'frais', 'délais', 'démarche', 'conseillers', 'Prime énergie', 'avis', 'contacts', 'opérateur', 'adresse', 'numéro de téléphone', 'service client', 'recharge pour voitures', 'énergies renouvelables', 'joindre votre fournisseur');


?>
