--
        -- Base de données: 'EnergieEdf'
--
create database if not exists EnergieEdf default character set utf8 collate utf8_general_ci;
use EnergieEdf;
-- --------------------------------------------------------
-- Création des tables

set foreign_key_checks =0;

-- Table agence
drop table if exists agence;
create table agence(
age_id int not null auto_increment primary key,
age_ville  varchar(100) not null,
age_departement varchar(100) not null,
age_telephone varchar (100) not null,
age_adresse varchar (1000) not null,
age_info varchar (15000) not null
)engine=innodb;


-- Table service
drop table if exists service;
create table service(
ser_id int not null auto_increment primary key ,
ser_libelle varchar(100) not null,
ser_prix float not null
)engine=innodb; 


-- Table client
drop table if exists client;
create table client(
cli_id int not null auto_increment primary key,
cli_nom  varchar(100) not null,
cli_prenom varchar(100) not null,
cli_login varchar(100) unique not null ,
cli_mdp varchar(500) not null,
cli_adresse varchar(1000) not null,
cli_email varchar(100) not null,
cli_telephone varchar(100) not null,
cli_agence int not null
)engine=innodb;

-- Table prestataire

drop table if exists prestataire;
create table prestataire(
pre_id int not null auto_increment primary key,
pre_nom  varchar(100) not null,
pre_prenom varchar(100) not null,
pre_login varchar(100) unique not null ,
pre_mdp varchar(500) not null,
pre_adresse varchar(100) not null,
pre_email varchar(100) not null,
pre_telephone varchar(100) not null,
pre_debut datetime,
pre_fin datetime,
pre_agence int not null
)engine=innodb;


-- Table employe
drop table if exists employe;
create table employe(
emp_id int not null auto_increment primary key,
emp_nom  varchar(100) not null,
emp_prenom varchar(100) not null,
emp_login varchar(100) unique not null ,
emp_mdp varchar(500) not null,
emp_profil varchar(100),
emp_agence int not null
)engine=innodb;


-- Table contra
drop table if exists contra;
create table contra(
con_id int not null auto_increment primary key,
con_debut datetime,
con_fin datetime,
con_type varchar(100),
con_statut varchar(100),
con_agence int not null,
con_client int not null
)engine=innodb;


-- Table comprendre
drop table if exists comprendre;
create table comprendre(
com_id int not null auto_increment primary key ,
com_contra int not null,
com_service int not null
)engine=innodb; 


set foreign_key_checks =1;

alter table client add constraint cs1 foreign key(cli_agence) references agence(age_id);
alter table prestataire add constraint cs2 foreign key(pre_agence) references agence(age_id);
alter table employe add constraint cs3 foreign key(emp_agence) references agence(age_id);
alter table contra add constraint cs4 foreign key(con_agence) references agence(age_id);
alter table contra add constraint cs5 foreign key(con_client) references client(cli_id);
alter table comprendre add constraint cs6 foreign key(com_contra) references contra(con_id);
alter table comprendre add constraint cs7 foreign key(com_service) references service(ser_id);

