<?php


$adresses = [
	'12 rue Pierre Richard 75012 Paris',
	'23 avenue Basile Boli 13005 Marseille',
	'15 rue Jean-Michel Aulas 69001 Lyon',
	'1 boulevard Alain Juppé 33000 Bordeaux',
	'56 rue Martine Aubry 59000 Lille',
	'10 rue de la Poste 35000 Rennes',
	'15 impasse des Canaris 44000 Nantes',
	'85 avenue Estrosi 06000 Nice',
	'55 rue de Colbert 34070 Montpellier',
	'41 rue 31100 Toulouse',
	'52 avenue des Moineaux Angers',
	'45 avenue Modou Ndao 63000 Clermont-Ferrand',
	'12 rue Matt Thuet 67100 Strasbourg',
	'14 rue des Acacias 30000 Nîmes',
	'15 place de la Cathédrale 51100 Reims',
	'13 rue Emmanuel Nwehla 75020 Paris',
	'52 avenue Charles-Henri Traoré 75014 Paris',
	'1 boulevard Planiteye 77000 Melun',
	'56 rue des Poissonniers 76610 Le Havre',
	'52 rue de la Moissonnière 38000 Grenoble'] ;



    ?>