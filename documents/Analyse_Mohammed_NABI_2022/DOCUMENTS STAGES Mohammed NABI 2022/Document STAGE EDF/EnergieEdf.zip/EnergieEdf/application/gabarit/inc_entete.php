<div style="margin-top:100px">
	<div class="row">
		<div class="col"><a href="index.php"><img src="_images/logo.jpg" width="180" alt="éolienne"></a></div>
		<div class="col">
			<h1 class="display-4"><?=SITE_NOM?></h1>
			<p class="lead">site multi users responsive avec Bootstrap</p>
		</div>
	</div>
</div>