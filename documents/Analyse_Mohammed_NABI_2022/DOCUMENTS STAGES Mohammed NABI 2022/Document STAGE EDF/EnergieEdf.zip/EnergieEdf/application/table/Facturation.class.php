<?php
/**
Classe créé par le générateur.
*/
class Facturation extends Table {
	public function __construct($id=0) {
		parent::__construct("facturation", "fac_id",$id);
	}
}
?>
