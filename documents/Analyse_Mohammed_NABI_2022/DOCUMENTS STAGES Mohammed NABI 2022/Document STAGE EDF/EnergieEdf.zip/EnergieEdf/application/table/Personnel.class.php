<?php
/**
Classe créé par le générateur.
*/
class Personnel extends Table {
	public function __construct($id=0) {
		parent::__construct("personnel", "per_id",$id);
	}
}
?>
