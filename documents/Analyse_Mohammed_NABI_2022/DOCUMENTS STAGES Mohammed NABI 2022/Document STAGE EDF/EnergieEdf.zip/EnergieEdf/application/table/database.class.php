        <?php
class Database
{
    static public function creer(string $sqlfile): string
    {
        $sql = file_get_contents($sqlfile);
        Table::$link->setAttribute(PDO::ATTR_EMULATE_PREPARES, 0);
        Table::$link->exec($sql);
        return $sql;
    }
    
    
    // 1 - Création des agences 

    static public function genererAgence(int $nbagence)
    {
require_once "../document/ville_departement.php";
        $sql = "insert into agence values ";
        $data = [];
        for ($i = 1; $i <= $nbagence; $i++) {
            shuffle($villes);
            $age_ville = $villes[0];
shuffle($departements);
            $age_departement = $departements[0];
            $n1 = mt_rand(1,9);              
            $n2 = mt_rand(0,9);
            $age_telephone = 0 . $n1 . $n2 . $n2-2 . $n2*2 . $n2. $n2+1 . $n2-1 . $n2 . $n2+3;
            shuffle($adresses);
            $age_adresse = $adresses[0];
            $age_info = "Ouvert du lundi à vendredi de 8h à 20h. Ouvert samedi et dimanche de 8h à 12h  ";
            $data[] = "(null, '$age_ville', '$age_departement','$age_telephone','$age_adresse','$age_info')";
            }
        return Table::$link->exec($sql . implode(",", $data));
    }

    
// 1 - Création des services
static public function genererService(int $nbservice)
{
    require "../document/Services.php";
        
    $sql = "insert into service values ";
$data = [];       
        for ($i = 0; $i < $nbservice; $i++) 
        {
            shuffle($libelles);
            $ser_libelle = $libelles[0];
            $ser_prix = mt_rand(1, 100);                
            $data[] = "(null, '$ser_libelle', '$ser_prix')";
}      
    return Table::$link->exec($sql . implode(",", $data));
}


    // 2 - Création des clients
    
    static public function genererClient(int $nbclient)
    {
        require_once "../document/adresses.php";
require_once "../document/personnes.php";
        $sql = "insert into client values ";
        $data = [];
        for ($i = 1; $i <= $nbclient; $i++) {
            shuffle($noms);
            $cli_nom = $noms[0];
            shuffle($prenoms);
            $cli_prenom = $prenoms[0];           
            $cli_login = "client $i";
            $cli_mdp = password_hash("mdp$i", PASSWORD_DEFAULT);
shuffle($adresses);
$cli_adresse = $adresses[1];
            $cli_email = "email" . $i . "@client_EDF.fr";
            $n = 0;
            $n1 = mt_rand(1,9);              
           $n2 = mt_rand(0,9);
$cli_telephone = 0 . $n1 . $n2 . $n2-2 . $n2*2 . $n2. $n2+1 . $n2-1 . $n2 . $n2+3;
                        $cli_agence = mt_rand(1, 60);
            $data[] = "(null,'$cli_nom', '$cli_prenom', '$cli_login', '$cli_mdp', '$cli_adresse', '$cli_email', '$cli_telephone', '$cli_agence')";
        }
        return Table::$link->exec($sql . implode(",", $data));
}


    // 2 - Création des prestataires
    
    static public function genererPrestataire(int $nbprestataire)
    {
        require "../document/personnes.php";
        $sql = "insert into prestataire values ";
        $data = [];
        for ($i = 1; $i <= $nbprestataire; $i++) {
            shuffle($noms);
            $pre_nom = $noms[0];
            shuffle($prenoms);
            $pre_prenom = $prenoms[0];           
            $pre_login = "client $i";
            $pre_mdp = password_hash("mdp$i", PASSWORD_DEFAULT);
            $pre_adresse = "$i rue des Clients 0123 énergie $i, France";
            $pre_email = "email" . $i . "@client_EDF.fr";
            $n = 0;
            $n1 = mt_rand(1,9);              
;           $n2 = mt_rand(0,9);
            $pre_telephone = $n . $n1 . $n2 . $n2 . $n2 . $n2. $n2 . $n2 . $n2 . $n2;
            $timestamp = time();
            $ts_debut = mktime(mt_rand(8, 20), 0, 0, mt_rand(1, 12), mt_rand(1, 30), 2019);
            $pre_debut = date("Y-m-d H:i:s", $ts_debut);
            $ts_fin = $ts_debut + 60 * 60 * 24 * mt_rand(1, 30);
            $pre_fin = date("Y-m-d H:i:s", $ts_fin);
            $pre_agence = mt_rand(1, 60);
            $data[] = "(null,'$pre_nom','$pre_prenom','$pre_login','$pre_mdp','$pre_adresse','$pre_email','$pre_telephone', '$pre_debut', '$pre_fin', '$pre_agence')";
        }
        return Table::$link->exec($sql . implode(",", $data));
    }


    // 3 - Création des employés
    static public function genererEmploye(int $nbemploye)
    {
        require "../document/personnes.php";
        $data = [];
        $sql = "insert into employe values";
        for ($i = 1; $i <= $nbemploye; $i++) {
            shuffle($noms);
            $emp_nom = $noms[0];
            shuffle($prenoms);
            $emp_prenom = $prenoms[0];   
            $emp_login = "employe$i";
            $emp_mdp = password_hash("mdp$i", PASSWORD_DEFAULT);
            $emp_profil = "";
            $emp_agence =  mt_rand(1, 60);
            $data[] = "(null,'$emp_nom','$emp_prenom','$emp_login','$emp_mdp', '$emp_profil', '$emp_agence')";
        }
        Table::$link->exec($sql . implode(",", $data));

        for ($i = 1; $i <= 160; $i++) {
            $sql = "UPDATE employe SET emp_profil='Gestionnaire'  WHERE emp_id=$i";
            $statement = Table::$link->prepare($sql);
            $statement->execute();
        }

        for ($i = 161; $i <= 190; $i++) {
            $sql = "UPDATE employe SET emp_profil='SRC' WHERE emp_id=$i";
            $statement = Table::$link->prepare($sql);
            $statement->execute();
        }

        for ($i = 191; $i <= 200; $i++) {
            $sql = "UPDATE employe SET emp_profil='Admin' WHERE emp_id=$i";
            $statement = Table::$link->prepare($sql);
            $statement->execute();
        }
    }

    
// 1 - Création des contra

static public function genererContra($nbcontra, $nbagence, $nbclient)
    {
        $sql = "insert into contra values ";
        $data = [];
        $statut = array("Initialisée", "Validée", "Annulée");
        $type = array("SRC", "Site web", "Agence");
        for ($i = 1; $i <= $nbcontra; $i++) 
        {
            $timestamp = time();
            $ts_debut = mktime(mt_rand(8, 20), 0, 0, mt_rand(1, 12), mt_rand(1, 30), 2019);
            $con_debut = date("Y-m-d H:i:s", $ts_debut);
            $ts_fin = $ts_debut + 60 * 60 * 24 * mt_rand(1, 30);
            $con_fin = date("Y-m-d H:i:s", $ts_fin);
            shuffle($type);
            $con_type = $type[0];
            shuffle($statut);
            $con_statut = $statut[0];
            $con_agence = mt_rand(1, $nbagence);
            $con_client = mt_rand(1,$nbclient);            
            $data[] = "(null,'$con_debut','$con_fin','$con_type','$con_statut','$con_agence', '$con_client')";
        }
        return Table::$link->exec($sql . implode(",", $data));
    }


// 1 - Création de la table associative (N/N) comprendre

static public function genererComprendre(int $nbcomprendre, int $nbcontra, int $nbservice)
{
    $sql = "insert into comprendre values ";
    $data = [];
    for ($i = 1; $i <= $nbcomprendre; $i++) {
        $com_contra =  mt_rand(1, $nbcontra);  
        $com_service = mt_rand(1, $nbservice);
        $data[] = "(null, '$com_contra','$com_service')";
    }
    return Table::$link->exec($sql . implode(",", $data));
}

}
