<?php
/**
Classe créé par le générateur.
*/
class Employe extends Table {
	public function __construct($id=0) {
		parent::__construct("employe", "emp_id",$id);
	}
}
?>
