<?php
/**
Classe créé par le générateur.
*/
class Service extends Table {
	public function __construct($id=0) {
		parent::__construct("service", "ser_id",$id);
	}
}
?>
