<?php
/**
Classe créé par le générateur.
*/
class Prestateur extends Table {
	public function __construct($id=0) {
		parent::__construct("prestateur", "pre_id",$id);
	}
}
?>
