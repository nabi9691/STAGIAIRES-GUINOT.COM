<?php
/**
Classe créé par le générateur.
*/
class Comprendre extends Table {
	public function __construct($id=0) {
		parent::__construct("comprendre", "com_id",$id);
	}
}
?>
