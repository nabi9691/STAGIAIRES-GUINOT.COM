<?php
/**
Classe créé par le générateur.
*/
class Contra extends Table 
{
	public function __construct($id=0) 
	{
		parent::__construct("contra", "con_id",$id);
	}

	static public function findByClient($id) 
	{
		$sql = "select com_contra, cli_nom, cli_prenom, cli_adresse, ser_libelle, ser_prix from comprendre, service, client, contra where com_service=ser_id and com_contra=con_id and con_client=cli_id and cli_id=:id";
$statement = self::$link->prepare($sql);
		$statement->bindValue(":id",$id,PDO::PARAM_INT);
		try {
			$statement->execute();
		} catch(Exception $e) {
			var_dump($e);
		}
		return $statement->fetchAll();
	}
}
?>
