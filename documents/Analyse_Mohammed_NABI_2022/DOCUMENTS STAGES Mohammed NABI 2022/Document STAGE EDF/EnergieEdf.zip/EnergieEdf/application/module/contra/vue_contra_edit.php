<form method="post" action="<?= hlien("contra", "edit") ?>">

    <!-- Id du contra -->
    <div class='form-group mt-5'> 
        <input type="hidden" name="con_id" id="con_id" value="<?= $id ?>" />
    </div>
    <div class="row mt-5">
        <!-- Client -->        
        <div class='form-group' <?php if(isset($_SESSION["cli_id"])) { ?> hidden <?php } ?>>         
            <label for='con_client' class="form-label">Client</label>
            <select class="form-select" name='con_client' id='con_client' >
            <?= HTMLselect("select cli_id,cli_login from client order by cli_id", "cli_id", "cli_login", $con_client) ?>
            </select>       
        </div>    
    </div>

    <div class="row mt-5">
        <div class="col">
            <!-- début du contra-->   
            <div class='form-group mt-5'> 
                <label for='con_debut' class="form-label">début du contra</label>
                <input id='con_debut' name='con_debut' type='datetime-local' size='50' value='<?= mhe($con_debut) ?>' class='form-control' />
            </div>
        </div>
        <div class="col">
            <!--fin du contra-->   
            <div class='form-group mt-5'>
                <label for='con_fin' class="form-label">Fin du contra</label>
                <input id='con_fin' name='con_fin' type='datetime-local' size='50' value='<?= mhe($con_fin) ?>' class='form-control'>
            </div>        
        </div>
    </div>
    
    <div class="row">
        <div class="col">
             <!-- Agence consernée-->
    <div class='form-group mt-5'>
        <label for='con_agence' class="form-label">Agence</label>
        <select name='con_agence' id='con_agence' class="form-select">
        <?= HTMLselect("select age_id,age_ville from agence order by age_ville", "age_id", "age_ville", $con_agence) ?>
        </select>
    </div>        
        </div>

        
    <div class="row">
        <div class="col">
               <!-- Type de réservation-->
    <label for='con_type' class="form-label mt-5">Type de réservation</label> 
    <div class='row form-group'>              
        <div class="col">
            <input type="radio" id="con_type" name="con_type" value="Site web" 
            <?php if(isset($_SESSION["cli_id"])) {?> checked 
            <?php } else if(isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "SRC" or $_SESSION["emp_profil"] == "Gestioonaire") { ?>
            disabled <?php } ?>>
            <label for="con_type">Site web</label>
        </div>
        <div class="col">
            <input type="radio" id="con_type" name="con_type" value="Agence" 
            <?php if(isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "Gestionnaire") {?> checked 
            <?php } else if(isset($_SESSION["cli_id"]) or $_SESSION["emp_id"] and $_SESSION["emp_profil"] == "SRC") { ?>
            disabled <?php } ?>>
            <label for="con_type">Agence</label>
        </div>
        <div class="col">
            <input type="radio" id="con_type" name="con_type" value="SRC"           
            <?php if(isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "SRC") {?> checked 
            <?php } else if(isset($_SESSION["cli_id"]) or $_SESSION["emp_id"] and $_SESSION["emp_profil"] == "Gestionnaire") { ?>
            disabled <?php } ?>>
            <label for="con_type">SRC</label>
        </div>        
    </div>        
        </div>

        <div class="col">                
    <!-- Statut de la location -->
    <label for='con_statut' class="form-label mt-5">Statut de la location</label> 
    <div class='row form-group'>              
        <div class="col">
            <input type="radio" id="con_statut" name="con_statut" value="Initialisée" <?php if(isset($_SESSION["cli_id"])) {?> checked <?php } ?>>
            <label for="con_statut">Initialisée</label>
        </div>
        <div class="col">
            <input type="radio" id="con_statut" name="con_statut" value="Validée" <?php if(isset($_SESSION["cli_id"])) { ?> disabled <?php } ?>>
            <label for="con_statut">Validée</label>
        </div>
        <div class="col">
            <input type="radio" id="con_statut" name="con_statut" value="Annulée" <?php if(isset($_SESSION["cli_id"])) { ?> disabled <?php } ?>>
            <label for="con_statut">Annulée</label>
        </div>
    </div>
        </div>
    </div>


        <div class="col">
        
     <!--Service-->
    <div class='form-group mt-5'>
        <label for='com_service' class="form-label">Service</label>
        <select name='com_service' id='com_service' class="form-select">
        <?= HTMLselect("select ser_id, ser_libelle from service order by ser_id ", "ser_id", "ser_libelle", $com_service) ?>
        </select>
    </div> 
        </div>
    </div>   
    

    <div class="row mt-5">
        <input class="btn btn-success" type="submit" name="btSubmit" value="Valider" />
    </div>
   
</form>

