<?= $message ?>
<h1>Authentification</h1>
<form method="post">
    <p><label for="cli_login">cli_login : </label><input type="text" name="cli_login" id="cli_login" value="<?=$cli_login?>" required></p>
    <p><label for="cli_pwd">mot de passe :</label><input type="password" name="cli_pwd" id="cli_pwd" required></p>
    <p><input type="submit" name="btSubmit" value="Valider"></p>
</form>