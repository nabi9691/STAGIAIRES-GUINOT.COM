<h1>Il y a une erreur</h1>
<p>
<?php echo $_GET["erreur"]->getMessage(); ?>
</p>