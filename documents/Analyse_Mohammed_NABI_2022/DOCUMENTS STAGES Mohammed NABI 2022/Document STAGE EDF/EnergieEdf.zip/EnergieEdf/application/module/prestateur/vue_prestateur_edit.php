        <form method="post" action="<?=hlien("prestateur","edit")?>">
		<input type="hidden" name="pre_id" id="pre_id" value="<?= $id ?>" />
                        <div class='form-group'>
                            <label for='pre_nom'>Nom</label>
                            <input id='pre_nom' name='pre_nom' type='text' size='50' value='<?=mhe($pre_nom)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_prenom'>Prenom</label>
                            <input id='pre_prenom' name='pre_prenom' type='text' size='50' value='<?=mhe($pre_prenom)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_login'>Login</label>
                            <input id='pre_login' name='pre_login' type='text' size='50' value='<?=mhe($pre_login)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_mdp'>Mdp</label>
                            <input id='pre_mdp' name='pre_mdp' type='text' size='50' value='<?=mhe($pre_mdp)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_adresse'>Adresse</label>
                            <input id='pre_adresse' name='pre_adresse' type='text' size='50' value='<?=mhe($pre_adresse)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_email'>Email</label>
                            <input id='pre_email' name='pre_email' type='text' size='50' value='<?=mhe($pre_email)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_telephone'>Telephone</label>
                            <input id='pre_telephone' name='pre_telephone' type='text' size='50' value='<?=mhe($pre_telephone)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_debut'>Debut</label>
                            <input id='pre_debut' name='pre_debut' type='text' size='50' value='<?=mhe($pre_debut)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_fin'>Fin</label>
                            <input id='pre_fin' name='pre_fin' type='text' size='50' value='<?=mhe($pre_fin)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='pre_agence'>Agence</label>
                            <input id='pre_agence' name='pre_agence' type='text' size='50' value='<?=mhe($pre_agence)?>'  class='form-control' />
                        </div>
		<input class="btn btn-success" type="submit" name="btSubmit" value="Enregistrer" />
	</form>              