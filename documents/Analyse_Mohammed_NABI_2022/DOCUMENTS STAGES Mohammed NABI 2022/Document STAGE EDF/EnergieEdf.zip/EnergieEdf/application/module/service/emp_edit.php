<?php if (isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "Admin") { ?> 
<div class="text-center">
    <h2 class="text-center">Service</h2> 
    <form method="post" action="<?=hlien("service","edit")?>">
        <input type="hidden" name="ser_id" id="ser_id" value="<?= $id ?>" />
                <div class='form-group'>
                    <label for='ser_libelle' class="form-label">Service</label>
                    <input id='ser_libelle' name='ser_libelle' type='text' size='50' value='<?=mhe($ser_libelle)?>'  class='form-control' />
                </div>
            
                <div class='form-group'>
                    <label for='ser_prix' class="form-label">Service</label>
                    <input id='ser_prix' name='ser_prix' type='text' size='50' value='<?=mhe($ser_prix)?>'  class='form-control' />
                </div>
                <input class="btn btn-success mt-5" type="submit" name="btSubmit" value="Valider" />
        </form>              
</div>
<?php } ?>