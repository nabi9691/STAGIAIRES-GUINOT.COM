        <form method="post" action="<?=hlien("comprendre","edit")?>">
		<input type="hidden" name="com_id" id="com_id" value="<?= $id ?>" />
                        <div class='form-group'>
                            <label for='com_contra'>Contra</label>
                            <input id='com_contra' name='com_contra' type='text' size='50' value='<?=mhe($com_contra)?>'  class='form-control' />
                        </div>
                        <div class='form-group'>
                            <label for='com_service'>Service</label>
                            <input id='com_service' name='com_service' type='text' size='50' value='<?=mhe($com_service)?>'  class='form-control' />
                        </div>
		<input class="btn btn-success" type="submit" name="btSubmit" value="Enregistrer" />
	</form>              