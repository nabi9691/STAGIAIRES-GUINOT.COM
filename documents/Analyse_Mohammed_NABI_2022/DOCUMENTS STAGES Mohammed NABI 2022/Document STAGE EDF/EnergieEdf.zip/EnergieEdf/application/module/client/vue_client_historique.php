<?php 
if (isset($_SESSION["cli_id"])) {?>
	<h2>Bienvenu sur votre éspace client EDF <?php echo $_SESSION["cli_prenom"]." ".$_SESSION["cli_nom"]?> dans votre espace personnel</h2>
	<h2>Mes consomations</h2>
 	<?php  } else { ?>
	<h2 class="text-center">Consulter vos factures EDF</h2>
	<?php } ?>

    <p><a class="btn btn-primary" href="<?=hlien("contra","edit","id",0)?>">Nouveau CONTRA</a></p>
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>				
			<th>Id</th>
			<th>Date du début du contra</th>
			<th>Date de la fin du contra</th>
			<th>Type de service</th>
			<th>Statut de la réservation</th>
			<th>Agence concernée </th>
			<th>Client</th>
			<th>Modifier</th>
			<th>Supprimer</th>
			</tr>
		</thead>
		<tbody>
		<?php
		foreach ( $result as $row) { 
			extract($row); ?>
		<tr>
			
			<td><?=mhe($row['con_id'])?></td>
			<td><?=mhe($row['con_debut'])?></td>
			<td><?=mhe($row['con_fin'])?></td>
			<td><?=mhe($row['con_type'])?></td>
			<td><?=mhe($row['con_statut'])?></td>
			<td><?=mhe($row['con_agence'])?></td>
			<td><?=mhe($row['con_client'])?></td>
			<a class="btn btn-warning" href="<?=hlien("contra","edit","id",$row["con_id"])?>">Modifier</a></td>
			<td><a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#supprimer">Supprimer</a></td>
		</tr>
		<?php } ?>
		</tbody>
	</table>



	
     
    <div class="modal fade" id="supprimer" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
     
                <!-- Header -->
                <div class="modal-header">
                    <h5 class="modal-title">Supprimer mon compte</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
     
                <!-- Body -->
                <div class="modal-body">
                    <p class="m-0">Voulez vous vrement supprimer votre compte ?</p>
                </div>
     
                <!-- Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Fermer</button>
                    <a class="btn btn-danger" href="<?=hlien("contra","del","id",$row["con_id"])?>">Oui,supprimer</a>                   
                </div>
     
            </div>
        </div>
    </div>