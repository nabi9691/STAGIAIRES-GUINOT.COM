<h2 class="text-center">Service</h2>
    <?php if (isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "Admin") { ?>
    	<p><a class="btn btn-primary" href="<?= hlien("service", "edit", "id", 0) ?>">Nouveau service</a></p>
    <?php } ?>
    <table class="table table-striped table-bordered table-hover">
    	<thead>
    		<tr>

    			<th>Id</th>
    			<th>Service</th>
				<th>Prix</th>
    			<?php if (isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "Admin") { ?>
    			<th>Modifier</th>
    			<th>Supprimer</th>
    			<?php } ?>
    		</tr>
    	</thead>
    	<tbody>
    		<?php
			foreach ($result as $row) {
				extract($row); ?>
    			<tr>
    				<td><?= mhe($row['ser_id']) ?></td>
    				<td><?= mhe($row['ser_libelle']) ?></td>
					<td><?= mhe($row['ser_prix']) ?></td>
<?php if (isset($_SESSION["emp_id"]) and $_SESSION["emp_profil"] == "Admin") { ?>
    				<td><a class="btn btn-warning" href="<?= hlien("service", "edit", "id", $row["ser_id"]) ?>">Modifier</a></td>
    				<td><a class="btn btn-danger" href="<?= hlien("service", "del", "id", $row["ser_id"]) ?>">Supprimer</a></td>
    				<?php } ?>
    			</tr>
    		<?php } ?>
    	</tbody>
    </table>