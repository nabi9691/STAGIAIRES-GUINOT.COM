<?php

class Ctr_database extends Ctr_controleur
{

    public function __construct($action)
    {
        parent::__construct("database", $action);
        $a = "a_$action";
        $this->$a();
    }

    public function a_creer()
    {
        $sql = Database::creer("../document/EnergieEdf.sql");
        require $this->gabarit;
    }

    public function a_dataset()
    {
        $nbagence = Database::genererAgence(60);           
        $nbservice = Database::genererService(10);           
        $nbclient = Database::genererClient(500);
        $nbprestataire = Database::genererPrestataire(30);           
        $nbemploye = Database::genererEmploye(200);   
        $nbcontra = Database::genererContra(500,60,500);           
        $nbcomprendre = Database::genererComprendre(250,500,10);           
        require $this->gabarit;
    }
}
