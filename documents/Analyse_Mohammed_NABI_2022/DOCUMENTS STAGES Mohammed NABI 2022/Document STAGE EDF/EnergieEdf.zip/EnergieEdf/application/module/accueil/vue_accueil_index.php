

<section class="container mt-5 pt-5 border border-3 border-danger p-5">
    <!-- Carousel -->
    <!-- Créer un carousel -->
    <div id="carousel" class="carousel slide carousel-fade" data-bs-ride="carousel">

        <!-- Indicateurs -->
        <ul class="carousel-indicators">
            <li data-bs-target="#carousel" data-bs-slide-to="0" class="active"></li>
            <li data-bs-target="#carousel" data-bs-slide-to="1"></li>
            <li data-bs-target="#carousel" data-bs-slide-to="2"></li>
        </ul>
        <!-- Contenu du carousel -->
        <div class="carousel-inner">
            <!--  Slide 1 -->
            <div class="carousel-item active" data-bs-interval="1000">
                                        <img src="../www/_images/data-center.jpg" class="w-100 d-block" alt="data-center">
<!-- Description -->
                <div class="carousel-caption w-25 bg-info">
                    <h5>L'energie est notre avenir, économisons la!</h5>
                    <p>Espace Client</p>
                </div>
            </div>

            <!-- Slide 2 -->
            <div class="carousel-item">
                <img src="../www/_images/energie-des-marees.jpg" class="w-100 d-block" alt="energie-des-marees">
                <!-- Description -->
                <div class="carousel-caption w-25 bg-info">
                    <h5>Ouverture compteur électricité - Mise en service simplifiée</h5>
                    <p>EDF, le leader de l'électricité</p>
                </div>
            </div>

            <!-- Slide 3 -->
            <div class="carousel-item">
                <img src="../www/_images/solaire2.jpg" class="w-100 d-block" alt="Solaire">
                <!-- Description -->
                <div class="carousel-caption w-25 bg-info">
                    <h5>Consultez et Réglez vos Factures EDF</h5>
                    <p>Siège social EDF : adresse, numéro de téléphone service client</p>
                </div>
            </div>


            <section>

        </div>

        <!-- Controles -->
        <button class="carousel-control-prev" href="#carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon bg-dark"></span>
            <span class="sr-only">Précédent</span>
        </button>
        <button class="carousel-control-next" href="#carousel" data-bs-slide="next">
            <span class="carousel-control-next-icon bg-dark"></span>
            <span class="sr-only">Suivant</span>
        </button>
    </div> <!--  -->

</section> <!-- /Carousel -->

<section class="container mt-5 p-5 border border-3 border-danger">
    <!--énergies renouvelables  -->   
    <div>
        <!-- 2 -->
        <h3 class="text-center border p-2 bg-danger">Nos énergies renouvelables</h3>

<div class="row pt-5">
            
            <!-- row1  -->
            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/solaire2.jpg" class="card-img-top" alt="Panneaux solaires">
                    <div class="card-title text-center">
                    <a class='btn btn-primary' href="https://www.youtube.com/watch?v=k_ut9pb3kjU" class="card-img-top" alt="Panneaux solaires ">Comment une centrale solaire photovoltaïque transforme la lumière en électricité - EDF</a>
                    </div>
                </div>
            </div>
<!--
            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/hydraulique.jpg" class="card-img-top" alt="Hydraulique">
                    <a href="https://www.youtube.com/watch?v=ABp9A-ozlV4" class="card-img-top" alt="Géothermie ">Découvrez en vidéo comment fonctionne une centrale géothermique. La production d’électricité dans une centrale géothermique est issue de la chaleur de la Terre.</a>
                    <div class="card-title text-center">
                    </div>
                </div>

            </div>
-->
            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/geothermie.jpg" class="card-img-top" alt="Geothermie">
                    <div class="card-title text-center">
                    <a class='btn btn-primary' href="https://www.youtube.com/watch?v=ABp9A-ozlV4" class="card-img-top" alt="Géothermie ">Découvrez en vidéo comment fonctionne une centrale géothermique. La production d’électricité dans une centrale géothermique est issue de la chaleur de la Terre.</a>
                    </div>
                </div>

            </div>

            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/logo.jpg" class="card-img-top" alt="...">
                    <div class="card-title text-center">
                    <a class='btn btn-primary' href='https://www.youtube.com/watch?v=v6ZNDQ80ELE'>Découvrez en vidéo comment fonctionne une centrale éolienne. La production d'électricité dans une centrale éolienne est issue de la force du vent.</a>
                    </div>

                </div>

            </div>

            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/energie-des-marees.jpg" class="card-img-top" alt="Energie des Marées">
                    <div class="card-title text-center">
                    <a class='btn btn-primary' href='https://www.youtube.com/watch?v=jNXiwcZYMpU'>Comment l'usine marémotrice de la Rance transforme les marées en électricité - EDF</a>
                    </div>
                </div>

            </div>

            <div class="col m-3">
                <div class="card" style="width: 18rem;">
                    <img src="../www/_images/hydraulique.jpg" class="card-img-top" alt="Hydraulique, solaire, éolienne...">
                    <div class="card-title text-center">                     
                    </div> <a class='btn btn-primary' href='https://youtu.be/9EWm6SpF1LQ'>Éoliennes, centrales solaires, barrages hydroélectriques,… autant de pistes pour générer de l’énergie dans le futur.</a>
                </div>
            </div>

        </div>
        <!--row1  -->
    </div>
    <!--row2  -->




    </div> <!-- 2 -->
</section> <!-- Catégories  -->

<section>

</section>

