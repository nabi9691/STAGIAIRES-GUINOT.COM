<?php if (isset($_SESSION["cli_id"])) {?>
	<h2>Bienvenu.e <?php echo $_SESSION["cli_prenom"]." ".$_SESSION["cli_nom"]?> dans votre espace personnel</h2>
	<h2>Ma consomation</h2>
 	<?php  } else { ?>
	<h2 class="text-center">Facturation</h2>
	<?php } ?>

    <p><a class="btn btn-primary" href="<?=hlien("contra","edit","id",0)?>">Nouveau contra</a></p>
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>				
			<th>Id</th>
			<th>Debut du contra</th>
			<th>Fin du contra </th>
			<th>Type de réservation</th>
			<th>Statut de la réservation</th>
			<th>Agence consernée</th>
			<th>Client</th>
			<th>Modifier</th>
			<th>Supprimer</th>
			</tr>
		</thead>
		<tbody>
		<?php
		foreach ( $result as $row) { 
			extract($row); ?>
		<tr>			
			<td><?=mhe($row['con_id'])?></td>
			<td><?=mhe($row['con_debut'])?></td>
			<td><?=mhe($row['con_fin'])?></td>
			<td><?=mhe($row['con_type'])?></td>
			<td><?=mhe($row['con_statut'])?></td>
			<td><?=mhe($row['con_agence'])?></td>
			<td><?=mhe($row['con_client'])?></td>
			<td><a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#supprimer" onclick="setId(<?=$row['con_id']?>)">Supprimer</a></td>
		</tr>
		<?php } ?>
		</tbody>
	</table>	
     
    <div class="modal fade" id="supprimer" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
     
                <!-- Header -->
                <div class="modal-header">
                    <h5 class="modal-title">Supprimer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
     
                <!-- Body -->
                <div class="modal-body">
                    <p class="m-0">Voulez vous vrement supprimer votre compte ?</p>
                </div>
     
                <!-- Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button class="btn btn-danger" onclick="supprimer()">Oui,supprimer</button>                   
                </div>     
            </div>
        </div>
    </div>

	<script>
		let con_id;
		function setId(id) 
		{
			con_id=id;
		}
		function supprimer() 
		{
			document.contra.href="<?=hlien("contra","del")?>&id=" + con_id;
		}
	</script>
