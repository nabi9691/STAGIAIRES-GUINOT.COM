<?php
class Ctr_authentification extends Ctr_controleur
{

	public function __construct($action)
	{
		parent::__construct("authentification", $action);
		$a = "a_$action";
		$this->$a();
	}

	function a_connexion()
	{
		$message = "";
		extract($_POST);
		if (isset($btSubmit)) {
			if ($row = Client::findByLogin($cli_login)) {
				//Si le mot de passe correspond
				if (password_verify($cli_pwd, $row["cli_mdp"])) {
					//création d'une session pour le client authentifié
					$_SESSION["id"]      = $row["cli_id"];;
					$_SESSION["cli_login"] = $row["cli_login"];
					header("location:" . hlien("client", "index"));
				} else {
					//Si password_verify échoue
					$message = "Erreur d'authentification. Veuillez recommencer.";
				}
			} else {
				//pas d'enregistrement correspondant au login
				$message = "Erreur d'authentification. Veuillez recommencer...";
			}
		} else {
			$cli_login="";
		}

		require $this->gabarit;
	}

	function a_deconnexion()
	{
		$_SESSION = [];
		session_destroy();
		header("location:" . hlien("authentification", "connexion"));
	}
}
