    <h2>prestateur</h2>
    <p><a class="btn btn-primary" href="<?=hlien("prestateur","edit","id",0)?>">Nouveau prestateur</a></p>
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
				
			<th>Id</th>
			<th>Nom</th>
			<th>Prenom</th>
			<th>Login</th>
			<th>Mdp</th>
			<th>Adresse</th>
			<th>Email</th>
			<th>Telephone</th>
			<th>Debut</th>
			<th>Fin</th>
			<th>Agence</th><th>modifier</th>
				<th>supprimer</th>
			</tr>
		</thead>
		<tbody>
		<?php
		foreach ( $result as $row) { 
			extract($row); ?>
		<tr>
			
			<td><?=mhe($row['pre_id'])?></td>
			<td><?=mhe($row['pre_nom'])?></td>
			<td><?=mhe($row['pre_prenom'])?></td>
			<td><?=mhe($row['pre_login'])?></td>
			<td><?=mhe($row['pre_mdp'])?></td>
			<td><?=mhe($row['pre_adresse'])?></td>
			<td><?=mhe($row['pre_email'])?></td>
			<td><?=mhe($row['pre_telephone'])?></td>
			<td><?=mhe($row['pre_debut'])?></td>
			<td><?=mhe($row['pre_fin'])?></td>
			<td><?=mhe($row['pre_agence'])?></td><td><a class="btn btn-warning" href="<?=hlien("prestateur","edit","id",$row["pre_id"])?>">Modifier</a></td>
			<td><a class="btn btn-danger" href="<?=hlien("prestateur","del","id",$row["pre_id"])?>">Supprimer</a></td>
		</tr>
		<?php } ?>
		</tbody>
	</table>